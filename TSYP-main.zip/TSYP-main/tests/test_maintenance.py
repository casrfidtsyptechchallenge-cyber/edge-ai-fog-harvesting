"""Tests for station/maintenance.py: electrode health forecast and fleet outliers, alone and in the dashboard
fed by the simulator (whose last node's electrode fouls)."""
import random
import sys
from pathlib import Path

from station.maintenance import HealthTrend, fleet_outliers, theil_sen
from station.dashboard.state import StationState

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "sim"))
from fake_node import CollectSink, Simulation  # noqa: E402


def feed(trend, slope_per_h, hours=2.0, start=0.9, noise=0.01, seed=0, spikes=0):
    rng = random.Random(seed)
    n = int(hours * 60)
    for i in range(n):        # one reading a minute (the trend keeps one every 3 min)
        t = i * 60.0
        y = start + slope_per_h * t / 3600 + rng.gauss(0, noise)
        if spikes and i % (n // spikes) == 6:   # on a kept point (every 3rd)
            y = 0.05  # a bad reading
        trend.add(t, y)
    return start + slope_per_h * hours


def test_a_steady_decline_is_forecast_with_an_interval_around_the_truth():
    tr = HealthTrend()
    now = feed(tr, -0.05)
    fc = tr.forecast()
    truth = (now - 0.25) / 0.05
    assert abs(fc["hours"] - truth) < 0.15 * truth
    assert fc["low_h"] <= truth <= fc["high_h"]


def test_a_flat_score_gets_no_forecast():
    tr = HealthTrend()
    feed(tr, 0.0, noise=0.02)
    fc = tr.forecast()
    assert fc is not None and fc["hours"] is None


def test_a_few_bad_readings_do_not_move_the_trend():
    clean, spiky = HealthTrend(), HealthTrend()
    feed(clean, -0.05)
    feed(spiky, -0.05, spikes=4)
    assert abs(spiky.forecast()["slope_per_h"] - clean.forecast()["slope_per_h"]) < 0.01


def test_too_few_points_give_nothing():
    tr = HealthTrend()
    feed(tr, -0.05, hours=0.2)
    assert tr.forecast() is None


def test_theil_sen_on_a_line():
    s, b = theil_sen([0, 1, 2, 3], [1.0, 0.8, 0.6, 0.4])
    assert abs(s + 0.2) < 1e-9 and abs(b - 1.0) < 1e-9


def test_fleet_outlier_is_the_one_ageing_fast():
    assert fleet_outliers({"n01": -0.001, "n02": -0.0012, "n03": -0.0009, "n04": -0.05}) == ["n04"]
    assert fleet_outliers({"n01": -0.001, "n02": -0.05}) == []          # two nodes: no fleet to compare with
    assert fleet_outliers({"n01": 0.0, "n02": 0.0, "n03": 0.0}) == []


def test_the_dashboard_forecasts_the_fouling_node_and_flags_it():
    sink = CollectSink()
    sim = Simulation(sink, nodes=3, seed=11, t0=1791747040.0)
    sim.start()
    for _ in range(3600):
        sim.step()
    st = StationState()
    for topic, payload, retain in sink.messages:
        st.ingest(topic, payload, retain, rx_ms=int(payload.get("ts", 0)) if isinstance(payload, dict) else 0)
    nodes = {n["node_id"]: n for n in st.summary(int(sim.t * 1000))["nodes"]}
    fc = nodes["n03"]["health"]["forecast"]
    assert fc is not None and fc["slope_per_h"] < 0 and fc["hours"] is not None
    assert nodes["n03"]["health"]["ages_fast"] is True
    assert not nodes["n01"]["health"]["ages_fast"] and not nodes["n02"]["health"]["ages_fast"]
