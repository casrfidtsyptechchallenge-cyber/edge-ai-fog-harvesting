"""Tests for ml/placement.py: the GP map passes near the measured yields, the suggestion keeps away from the
nodes, and on simulated fog fields it beats a random spot. Skipped without numpy."""
import pytest

np = pytest.importorskip("numpy")

from ml import placement as pl  # noqa: E402


def test_the_map_passes_near_the_measured_yields_and_is_unsure_far_away():
    X = np.array([[0, 0], [30, 0], [0, 30], [30, 30.0]])
    y = np.array([1.0, 2.0, 1.5, 3.0])
    gp = pl.GP().fit(X, y)
    mean, sd = gp.predict(X)
    assert np.allclose(mean, y, atol=0.2)
    _, sd_far = gp.predict(np.array([[300.0, 300.0]]))
    assert sd_far[0] > 3 * sd.max()


def test_the_suggestion_keeps_its_distance_and_goes_towards_the_good_side():
    X = np.array([[0, 0], [30, 0], [0, 30], [30, 30.0], [15, 15.0]])
    y = np.array([1.0, 2.0, 1.0, 3.0, 2.0])
    p, *_ = pl.suggest(X, y, (-10, 40, -10, 40))
    assert np.min(np.linalg.norm(X - p, axis=1)) >= pl.MIN_GAP_M
    assert p[0] > 15 and p[1] > 15            # the high-yield corner


def test_it_beats_a_random_spot_on_simulated_fields():
    r = pl.evaluate(n_nodes=(5,), fields=40, seed=7)[5]
    assert r["gp"] > r["random"]
