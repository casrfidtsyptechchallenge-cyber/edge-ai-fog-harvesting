"""Tests for station/water/allocation.py: fair daily quotas (max-min per person, prudent supply)."""
import pytest

from station.water.allocation import plan, prudent_supply, quantile, water_filling


def test_prudent_supply_uses_a_low_quantile_and_a_reserve():
    assert quantile([10, 20, 30, 40, 50], 0.2) == pytest.approx(18.0)
    assert prudent_supply(20, [10, 20, 30, 40, 50], 0.2, 0.1) == pytest.approx((20 + 18) * 0.9)


def test_enough_water_meets_every_need_and_no_more():
    q = water_filling(1000, {"a": (4, 15), "b": (2, 15)})
    assert q == {"a": 60.0, "b": 30.0}


def test_short_water_gives_the_same_level_per_person():
    q = water_filling(60, {"a": (4, 15), "b": (2, 15), "c": (1, 15)})
    assert sum(q.values()) == pytest.approx(60, abs=0.05)
    per_person = {c: q[c] / n for c, n in (("a", 4), ("b", 2), ("c", 1))}
    assert max(per_person.values()) - min(per_person.values()) < 0.01


def test_a_small_need_is_met_and_its_rest_goes_to_the_others():
    q = water_filling(50, {"small": (1, 5), "a": (3, 15)})
    assert q["small"] == pytest.approx(5.0)
    assert q["a"] == pytest.approx(45.0, abs=0.05)


def test_below_the_vital_minimum_it_is_shared_by_people():
    q = water_filling(9, {"a": (4, 15), "b": (2, 15)}, vital_l_per_person=3.0)  # 18 L vital needed, 9 L there
    assert q["a"] == pytest.approx(6.0) and q["b"] == pytest.approx(3.0)


def test_nothing_to_share():
    assert water_filling(0, {"a": (4, 15)}) == {"a": 0.0}
    assert water_filling(10, {"a": (0, 15)}) == {"a": 0.0}


def test_the_plan_never_promises_more_than_the_prudent_supply():
    p = plan(stock_l=20, daily_production_l=[30, 45, 50, 25, 60], households={"a": (5, 15), "b": (3, 15)})
    assert sum(p["quotas"].values()) <= p["supply_l"] + 0.05
    assert p["short"] is True
