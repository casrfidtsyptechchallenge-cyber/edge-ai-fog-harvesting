"""Where to put the next collector? A Gaussian-process map of the site's yield, from the nodes already there.

Each node reports how much water it collects (M2 runs: grams per hour of fog, or per unit of fog). Collectors a
few tens of metres apart see different fog (slope, wind, obstacles). A Gaussian process (GP) learns a smooth map
of the yield from the nodes' positions, with an uncertainty that grows away from them. The next collector goes
where the expected yield is highest (UCB with kappa = 0: on tuning fields, trusting the map beat adding an
exploration bonus, since one collector is placed at a time).

Honest limits: with 3 nodes the map is mostly prior; the suggestion becomes useful from about 5 nodes or with
yields from several fog seasons. The evaluation (evaluate()) measures this on simulated fog fields.

python -m ml placement nodes.csv  (columns node_id,x_m,y_m,yield)  ->  the suggested position and the map.
"""
import csv

import numpy as np

LENGTH_M = 25.0      # how far the fog stays alike (kernel length scale)
NOISE = 0.15         # yield measurement noise, relative to the yields' spread
KAPPA = 0.0          # UCB weight of the uncertainty: 0 = trust the map (best of 0/0.5/1/2 on tuning fields;
                     # one collector is placed at a time, exploring has no later payoff)
MIN_GAP_M = 5.0      # not right next to an existing collector


class GP:
    def __init__(self, length=LENGTH_M, noise=NOISE):
        self.length, self.noise = length, noise

    def _k(self, A, B):
        d2 = ((A[:, None, :] - B[None, :, :]) ** 2).sum(-1)
        return np.exp(-0.5 * d2 / self.length ** 2)

    def fit(self, X, y):
        self.X = np.asarray(X, float)
        y = np.asarray(y, float)
        self.mu, self.sd = y.mean(), y.std() + 1e-9
        z = (y - self.mu) / self.sd
        K = self._k(self.X, self.X) + self.noise ** 2 * np.eye(len(z))
        self.L = np.linalg.cholesky(K)
        self.alpha = np.linalg.solve(self.L.T, np.linalg.solve(self.L, z))
        return self

    def predict(self, Xs):
        Xs = np.asarray(Xs, float)
        Ks = self._k(Xs, self.X)
        mean = Ks @ self.alpha
        v = np.linalg.solve(self.L, Ks.T)
        var = np.clip(1.0 - (v * v).sum(0), 1e-12, None)
        return self.mu + self.sd * mean, self.sd * np.sqrt(var)


def suggest(X, y, bounds, kappa=KAPPA, grid=60):
    """bounds = (xmin, xmax, ymin, ymax). Returns (best point, its mean, its sd, the grid and its UCB)."""
    gp = GP().fit(X, y)
    xs = np.linspace(bounds[0], bounds[1], grid)
    ys = np.linspace(bounds[2], bounds[3], grid)
    G = np.array([(a, b) for b in ys for a in xs])
    mean, sd = gp.predict(G)
    ucb = mean + kappa * sd
    near = (np.sqrt(((G[:, None, :] - np.asarray(X, float)[None, :, :]) ** 2).sum(-1)) < MIN_GAP_M).any(1)
    ucb = np.where(near, -np.inf, ucb)
    i = int(np.argmax(ucb))
    return G[i], float(mean[i]), float(sd[i]), G, ucb


def read_nodes(path):
    with open(path, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    X = np.array([[float(r["x_m"]), float(r["y_m"])] for r in rows])
    y = np.array([float(r["yield"]) for r in rows])
    return [r["node_id"] for r in rows], X, y


# ---------------------------------------------------------------- evaluation on simulated fog fields

def random_field(rng, size=100.0, bumps=4):
    """A smooth yield field: a gradient (slope, sea side) plus a few fog pockets."""
    g = rng.normal(0, 1, 2)
    centres = rng.uniform(0, size, (bumps, 2))
    amps = rng.uniform(0.5, 1.5, bumps)
    widths = rng.uniform(10, 30, bumps)

    def f(P):
        P = np.atleast_2d(P)
        v = 1.0 + 0.4 * (P @ g) / size
        for c, a, w in zip(centres, amps, widths):
            v = v + a * np.exp(-((P - c) ** 2).sum(1) / (2 * w * w))
        return v
    return f


def evaluate(n_nodes=(3, 5, 8), fields=200, seed=0, size=100.0, noise=0.10, kappa=KAPPA):
    """Mean true yield at the suggested spot, against: a random spot, next to the best node, and the best spot
    of the whole site (the ceiling), as a share of the way from random to the ceiling."""
    rng = np.random.default_rng(seed)
    grid = np.array([(a, b) for b in np.linspace(0, size, 60) for a in np.linspace(0, size, 60)])
    out = {}
    for n in n_nodes:
        gp_v, rnd_v, nxt_v, top_v = [], [], [], []
        for _ in range(fields):
            f = random_field(rng, size)
            X = rng.uniform(0, size, (n, 2))
            y = f(X) * (1 + noise * rng.normal(size=n))
            p, *_ = suggest(X, y, (0, size, 0, size), kappa=kappa)
            gp_v.append(f(p)[0])
            rnd_v.append(f(rng.uniform(0, size, 2))[0])
            b = X[np.argmax(y)]
            ang = rng.uniform(0, 2 * np.pi)
            nxt_v.append(f(np.clip(b + MIN_GAP_M * np.array([np.cos(ang), np.sin(ang)]), 0, size))[0])
            top_v.append(f(grid).max())
        g, r, nx, t = map(np.mean, (gp_v, rnd_v, nxt_v, top_v))
        out[n] = {"gp": g, "random": r, "next_to_best": nx, "best_possible": t,
                  "gp_share_of_gain": (g - r) / (t - r), "next_share_of_gain": (nx - r) / (t - r),
                  "gp_beats_next_to_best": float(np.mean(np.array(gp_v) > np.array(nxt_v)))}
    return out
