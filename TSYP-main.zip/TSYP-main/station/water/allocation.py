"""Fair daily quotas for the water point (M9): share tomorrow's water so the promise holds and nobody is left out.

Today every household card has the same fixed quota. When the fog is poor, a fixed quota either runs the tank dry
(the last households get nothing) or wastes water that stays in the tank. This planner proposes tomorrow's quota
of each card from:

  * the water available, counted carefully: what is in the tank, plus a PRUDENT production for tomorrow, the
    `prudence` quantile of the recent daily productions (default the 20th percentile: 4 days in 5 bring at
    least that much), minus a reserve kept back (default 10 %);
  * each household's need: people x litres per person (both set by the operators; no name is ever stored).

Sharing rule, max-min fair ("water-filling"): one level of litres per person rises for everyone until the water
runs out or the household's need is met. Nobody gets more than they need; nobody gets less than anyone else per
person unless their need is smaller. If the water does not cover even the vital minimum per person, it is shared
in proportion to the people (still everyone gets something).

python -m station.water plan      the proposal from the ledger's last days; --apply writes it as the quotas.
"""


def quantile(values, q):
    s = sorted(values)
    if not s:
        return 0.0
    pos = (len(s) - 1) * q
    lo = int(pos)
    hi = min(lo + 1, len(s) - 1)
    return s[lo] + (s[hi] - s[lo]) * (pos - lo)


def prudent_supply(stock_l, daily_production_l, prudence=0.2, reserve=0.10):
    """Litres that can be promised for tomorrow."""
    production = quantile(daily_production_l, prudence) if daily_production_l else 0.0
    return max(0.0, (stock_l + production) * (1.0 - reserve))


def water_filling(supply_l, households, vital_l_per_person=3.0):
    """households: {card: (people, need_l_per_person)}. Returns {card: litres}.
    Max-min fair per person, capped by each household's need."""
    people = {c: max(0, int(p)) for c, (p, _) in households.items()}
    need = {c: people[c] * max(0.0, float(n)) for c, (_, n) in households.items()}
    total_people = sum(people.values())
    if total_people == 0 or supply_l <= 0:
        return {c: 0.0 for c in households}
    vital = {c: min(need[c], people[c] * vital_l_per_person) for c in households}
    if supply_l <= sum(vital.values()):          # scarcity: in proportion to the people, up to their need
        share = supply_l / total_people
        return {c: round(min(need[c], people[c] * share), 2) for c in households}
    # water-filling on the level per person: find L with sum(min(need_c, people_c * L)) = supply
    lo, hi = 0.0, max((need[c] / people[c]) for c in households if people[c]) if total_people else 0.0
    if sum(need.values()) <= supply_l:
        return {c: round(need[c], 2) for c in households}
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        if sum(min(need[c], people[c] * mid) for c in households) > supply_l:
            hi = mid
        else:
            lo = mid
    return {c: round(min(need[c], people[c] * lo), 2) for c in households}


def plan(stock_l, daily_production_l, households, prudence=0.2, reserve=0.10, vital_l_per_person=3.0):
    """The proposal: {"supply_l", "quotas": {card: litres}, "level_l_per_person", "short": bool}."""
    supply = prudent_supply(stock_l, daily_production_l, prudence, reserve)
    quotas = water_filling(supply, households, vital_l_per_person)
    people = sum(max(0, int(p)) for p, _ in households.values())
    need = sum(max(0, int(p)) * n for p, n in households.values())
    return {"supply_l": round(supply, 2), "quotas": quotas,
            "level_l_per_person": round(sum(quotas.values()) / people, 2) if people else 0.0,
            "short": sum(quotas.values()) < need - 1e-6}
