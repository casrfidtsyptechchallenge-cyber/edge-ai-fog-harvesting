"""Predictive maintenance of the electrodes (M5c -> station): "clean the electrode of n03 in about 6 h".

M5c reports an electrode health score (0..1, 1 = new) in every telemetry. A dirty or blunt electrode needs a
higher voltage to start the corona, so the score slowly falls. This module turns the score's history into a
forecast, for the dashboard:

  * trend: Theil-Sen slope of the score over the last WINDOW_H hours (one point every 3 min). The median of all
    pairwise slopes: a few bad readings do not move it, unlike a least-squares fit;
  * forecast: hours until the trend line reaches HEALTH_BAD (0.25, "clean or replace now"), with an 80 %
    interval from a bootstrap of the points. Nothing is forecast when the score is not falling clearly
    (interval crossing a zero slope), or when there are too few points: no number is better than a guess;
  * fleet: a node whose slope is far below the others' (robust z-score, median and MAD) ages abnormally fast:
    a damaged electrode, a leak, a dirtier spot. That needs a look, whatever its score today.

No dependency (plain Python): it runs on the Raspberry Pi with requirements.txt only.
"""
import math
import random

HEALTH_BAD = 0.25
WINDOW_H = 3.0          # the trend looks back this far
POINT_EVERY_S = 180.0   # one point every 3 min: at most 60 points over the window (cheap on a Raspberry Pi)
MIN_POINTS = 10
MIN_SPAN_H = 0.5
BOOT = 100
RECOMPUTE_S = 60.0
FLEET_Z = 3.0


def theil_sen(ts, ys):
    slopes = []
    n = len(ts)
    for i in range(n):
        for j in range(i + 1, n):
            dt = ts[j] - ts[i]
            if dt > 0:
                slopes.append((ys[j] - ys[i]) / dt)
    if not slopes:
        return None, None
    slopes.sort()
    m = len(slopes)
    slope = slopes[m // 2] if m % 2 else 0.5 * (slopes[m // 2 - 1] + slopes[m // 2])
    resid = sorted(y - slope * t for t, y in zip(ts, ys))
    k = len(resid)
    icpt = resid[k // 2] if k % 2 else 0.5 * (resid[k // 2 - 1] + resid[k // 2])
    return slope, icpt


def _hours_to(level, slope_per_h, icpt, t_now_h):
    if slope_per_h >= 0:
        return None
    now = icpt + slope_per_h * t_now_h
    return max(0.0, (level - now) / slope_per_h) if now > level else 0.0


class HealthTrend:
    """One node's score history and forecast."""

    def __init__(self, seed=0):
        self.points = []            # (t in hours, score)
        self.last_t = None
        self.cache = None
        self.cache_t = None
        self.rng = random.Random(seed)

    def add(self, t_s, score):
        if score is None or not math.isfinite(score):
            return
        if self.last_t is not None and t_s - self.last_t < POINT_EVERY_S:
            return
        self.last_t = t_s
        self.points.append((t_s / 3600.0, float(score)))
        cutoff = t_s / 3600.0 - WINDOW_H
        while self.points and self.points[0][0] < cutoff:
            self.points.pop(0)
        self.cache_t = None

    def forecast(self, t_now_s=None):
        """dict(slope_per_h, hours, low_h, high_h, score_now) or None (not enough, or not falling clearly).
        Recomputed at most every RECOMPUTE_S."""
        now = t_now_s if t_now_s is not None else (self.last_t or 0.0)
        if self.cache_t is not None and now - self.cache_t < RECOMPUTE_S:
            return self.cache
        self.cache_t = now
        self.cache = self._forecast()
        return self.cache

    def _forecast(self):
        pts = self.points
        if len(pts) < MIN_POINTS or pts[-1][0] - pts[0][0] < MIN_SPAN_H:
            return None
        ts, ys = [p[0] for p in pts], [p[1] for p in pts]
        slope, icpt = theil_sen(ts, ys)
        if slope is None:
            return None
        boot = []
        for _ in range(BOOT):
            idx = [self.rng.randrange(len(pts)) for _ in pts]
            s, _ = theil_sen([ts[i] for i in idx], [ys[i] for i in idx])
            if s is not None:
                boot.append(s)
        boot.sort()
        lo_s, hi_s = boot[int(0.1 * len(boot))], boot[int(0.9 * len(boot)) - 1]
        if hi_s >= 0 or slope >= 0:               # not clearly falling: no forecast
            return {"slope_per_h": round(slope, 5), "hours": None, "low_h": None, "high_h": None,
                    "score_now": round(icpt + slope * ts[-1], 3)}
        t_now = ts[-1]
        hours = _hours_to(HEALTH_BAD, slope, icpt, t_now)
        fast = _hours_to(HEALTH_BAD, lo_s, icpt + (slope - lo_s) * t_now, t_now)   # steeper slope: sooner
        slow = _hours_to(HEALTH_BAD, hi_s, icpt + (slope - hi_s) * t_now, t_now)
        return {"slope_per_h": round(slope, 5), "hours": None if hours is None else round(hours, 1),
                "low_h": None if fast is None else round(fast, 1), "high_h": None if slow is None else round(slow, 1),
                "score_now": round(icpt + slope * t_now, 3)}


def fleet_outliers(slopes, z=FLEET_Z):
    """slopes: {node: slope per hour}. Nodes ageing far faster than the others (robust z below -z).
    Needs 3 nodes or more."""
    vals = [v for v in slopes.values() if v is not None]
    if len(vals) < 3:
        return []
    s = sorted(vals)
    med = s[len(s) // 2] if len(s) % 2 else 0.5 * (s[len(s) // 2 - 1] + s[len(s) // 2])
    dev = sorted(abs(v - med) for v in vals)
    mad = dev[len(dev) // 2] if len(dev) % 2 else 0.5 * (dev[len(dev) // 2 - 1] + dev[len(dev) // 2])
    scale = 1.4826 * mad + 1e-4                     # + a floor: identical slopes must not make noise an outlier
    return sorted(n for n, v in slopes.items() if v is not None and (v - med) / scale < -z)
