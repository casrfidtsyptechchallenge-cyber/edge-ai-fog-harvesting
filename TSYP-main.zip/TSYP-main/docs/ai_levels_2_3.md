# AI levels 2 and 3: what was built, measured and decided

Every number here comes from simulation (toy nodes, simulated fog fields), decided on tuning seeds and measured
on seeds not used for tuning. They show how the methods behave, not field performance.

| # | What | Where | Result | Decision |
|---|---|---|---|---|
| 4 | "M6 that remembers": Thompson-sampling bandit over HV levels, one memory per fog band | `HvController`, `policy = Bandit` | **worse** than the default sweep: 9.41 vs 9.97 g/Wh, 17.4 vs 20.1 g/h (24 nodes × 8 h, paired); as safe (faults 0.00 vs 0.01/h). Without fog bands: the same | kept as an option, **off by default**: the sweep already matches the best fixed level, so exploring only costs water |
| 5 | Arc prediction from current + sound (electret microphone) | not built | needs the HV stage and recorded sound: no data, no claim | report: future work |
| 6 | Predictive maintenance of the electrode | `station/maintenance.py`, dashboard | Theil-Sen trend of the M5c score, hours until "clean now" with an 80 % bootstrap interval; fleet outlier (robust z) flags the node that ages fast. In the simulator the fouling node n03 is forecast and flagged, the others not | **in the dashboard** ("clean in ~N h", alert) |
| 7 | Fair daily quotas | `station/water/allocation.py`, `python -m station.water plan` | prudent supply (stock + 20th percentile of past days' production − 10 % reserve), max-min fair per person, capped by need; below the vital minimum, shared by people | **in the water point** (proposal; `--apply` writes the quotas) |
| 8 | Where to put the next collector | `ml/placement.py`, `python -m ml placement` | GP map of the yield; on 300 fresh simulated fields the suggested spot gets 39 / 50 / **66 %** of the way from a random spot to the site's best with 3 / 5 / 8 nodes, against 37 / 46 / 55 % for "next to the best node" (better on 53 / 55 / 68 % of fields) | tool for the deployment; useful from about 5 nodes |

## 4. Bandit policy (M6)

Same measuring as the sweep (90 s dwell judged after 30 s, slope of the load cell, water per unit of fog), same
safety (arc ceiling, arc risk, novelty guard), same goal; only the choice of the next level differs. Levels are
counted from the corona onset (M5c), so they follow the electrode as it fouls; older results fade (0.97 per
dwell); at most two steps up at once. Run: `pio test -e native` prints the paired comparison
(`test_the_bandit_policy_is_as_safe_as_the_sweep`).

## 6. Electrode forecast

One point every 3 min over the last 3 h (60 points at most: about 0.03 s per forecast, recomputed once a minute
per node, fine on a Raspberry Pi). No forecast when the score is not clearly falling (the bootstrap interval of
the slope reaches zero) or with fewer than 10 points over 30 min.

## 7. Quotas

```
python -m station.water plan --stock 40 --production 60 45 80 30 55 --people "card 7=5" --people "card 8=2"
Water that can be promised: 73.8 L (short: shared fairly), 9.2 L per person on average
```
People per household and litres per person are set by the operators; no name is stored.

## 8. Placement

`kappa` (exploration bonus) was chosen on tuning fields among 0, 0.5, 1, 2: 0 was best, since one collector is
placed at a time and exploring has no later payoff. `python -m ml placement --evaluate` reproduces the table.
